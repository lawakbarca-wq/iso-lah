
  # Import HTML as Editable Design

  This is a code bundle for Import HTML as Editable Design. The original project is available at https://www.figma.com/design/WGlMmCeXCqRUru3t6UX4Ae/Import-HTML-as-Editable-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  